'Garamond' =>  
    [  
        'normal' => $distFontDir . '/Garamond - Garamond - Regular.ttf',  
        'bold' => $distFontDir . '/Garamond-Bold - Garamond - Bold.ttf',  
        'italic' => $distFontDir . '/Garamond-Italic - Garamond - Italic.ttf',  
        'bold_italic' => $distFontDir . '/Garamond-BoldItalic-04.ttf'  
    ],  